System.register(["github:aurelia/bootstrapper@0.9.3/system/index"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});