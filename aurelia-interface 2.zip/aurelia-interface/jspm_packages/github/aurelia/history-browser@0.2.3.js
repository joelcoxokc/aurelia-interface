System.register(["github:aurelia/history-browser@0.2.3/system/index"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});