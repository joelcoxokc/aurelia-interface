System.register(["github:aurelia/loader-default@0.4.1/system/index"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});