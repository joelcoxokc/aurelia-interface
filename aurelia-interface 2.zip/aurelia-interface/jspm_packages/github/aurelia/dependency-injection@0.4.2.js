System.register(["github:aurelia/dependency-injection@0.4.2/system/index"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});