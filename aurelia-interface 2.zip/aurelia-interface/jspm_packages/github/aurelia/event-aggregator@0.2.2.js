System.register(["github:aurelia/event-aggregator@0.2.2/system/index"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});