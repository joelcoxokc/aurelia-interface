/* */ 
"format register";
"use strict";

var ONE_WAY = exports.ONE_WAY = 1;
var TWO_WAY = exports.TWO_WAY = 2;
var ONE_TIME = exports.ONE_TIME = 3;
exports.__esModule = true;