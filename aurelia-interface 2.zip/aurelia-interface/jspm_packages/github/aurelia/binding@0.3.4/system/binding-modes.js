/* */ 
System.register([], function (_export) {
  "use strict";

  var ONE_WAY, TWO_WAY, ONE_TIME;
  return {
    setters: [],
    execute: function () {
      ONE_WAY = _export("ONE_WAY", 1);
      TWO_WAY = _export("TWO_WAY", 2);
      ONE_TIME = _export("ONE_TIME", 3);
    }
  };
});