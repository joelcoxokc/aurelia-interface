/* */ 
"format register";
export var ONE_WAY = 1;
export var TWO_WAY = 2;
export var ONE_TIME = 3;
