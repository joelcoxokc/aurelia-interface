/* */ 
"format register";
define(["exports","./origin","./resource-type","./metadata"], function (exports, _origin, _resourceType, _metadata) {
  "use strict";

  exports.Origin = _origin.Origin;
  exports.ResourceType = _resourceType.ResourceType;
  exports.Metadata = _metadata.Metadata;
});