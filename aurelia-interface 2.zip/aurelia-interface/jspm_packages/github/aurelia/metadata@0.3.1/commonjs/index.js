/* */ 
"format register";
"use strict";

exports.Origin = require("./origin").Origin;
exports.ResourceType = require("./resource-type").ResourceType;
exports.Metadata = require("./metadata").Metadata;